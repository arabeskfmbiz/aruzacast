<template>
    <span class="badge small badge-primary ml-2">
        {{ $gettext('Advanced') }}
    </span>
</template>
