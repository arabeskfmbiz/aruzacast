import initBase from '~/base.js';

import SetupStation from '~/components/Setup/Station.vue';

export default initBase(SetupStation);
