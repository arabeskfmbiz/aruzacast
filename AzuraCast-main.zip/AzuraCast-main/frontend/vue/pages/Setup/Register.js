import initBase from '~/base.js';

import SetupRegister from '~/components/Setup/Register.vue';

export default initBase(SetupRegister);
