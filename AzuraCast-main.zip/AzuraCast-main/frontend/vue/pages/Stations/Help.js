import initBase from '~/base.js';

import Help from '~/components/Stations/Help.vue';

export default initBase(Help);
