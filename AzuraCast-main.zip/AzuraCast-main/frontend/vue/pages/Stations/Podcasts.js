import initBase from '~/base.js';

import '~/vendor/fancybox';
import '~/vendor/luxon';

import Podcasts from '~/components/Stations/Podcasts.vue';

export default initBase(Podcasts);
