import initBase from '~/base.js';

import LiquidsoapConfig from '~/components/Stations/LiquidsoapConfig.vue';

export default initBase(LiquidsoapConfig);
