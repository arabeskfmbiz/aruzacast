import initBase from '~/base.js';

import HlsStreams from '~/components/Stations/HlsStreams.vue';

export default initBase(HlsStreams);
