import initBase from '~/base.js';

import '~/vendor/luxon';

import Queue from '~/components/Stations/Queue.vue';

export default initBase(Queue);
