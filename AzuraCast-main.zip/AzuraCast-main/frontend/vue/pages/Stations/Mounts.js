import initBase from '~/base.js';

import Mounts from '~/components/Stations/Mounts.vue';

export default initBase(Mounts);
