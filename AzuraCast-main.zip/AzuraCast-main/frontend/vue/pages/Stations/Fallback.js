import initBase from '~/base.js';

import Fallback from '~/components/Stations/Fallback.vue';

export default initBase(Fallback);
