import initBase from '~/base.js';

import AdminLogs from '~/components/Admin/Logs.vue';

export default initBase(AdminLogs);
