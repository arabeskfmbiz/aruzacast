import initBase from '~/base.js';

import AdminSettings from '~/components/Admin/Settings.vue';

export default initBase(AdminSettings);
