import initBase from '~/base.js';
import AdminApiKeys from '~/components/Admin/ApiKeys.vue';

export default initBase(AdminApiKeys);
