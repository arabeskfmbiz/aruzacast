import initBase from '~/base.js';

import AdminGeoLite from '~/components/Admin/GeoLite.vue';

export default initBase(AdminGeoLite);
