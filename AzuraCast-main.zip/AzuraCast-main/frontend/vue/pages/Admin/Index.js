import initBase from '~/base.js';

import AdminIndex from '~/components/Admin/Index.vue';

export default initBase(AdminIndex);
