import initBase from '~/base.js';

import AdminCustomFields from '~/components/Admin/CustomFields.vue';

export default initBase(AdminCustomFields);
