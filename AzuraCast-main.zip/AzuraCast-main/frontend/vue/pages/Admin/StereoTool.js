import initBase from '~/base.js';

import AdminStereoTool from '~/components/Admin/StereoTool.vue';

export default initBase(AdminStereoTool);
