import initBase from '~/base.js';

import '~/vendor/fancybox';

import AdminBranding from '~/components/Admin/Branding.vue';

export default initBase(AdminBranding);
