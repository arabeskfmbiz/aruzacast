import initBase from '~/base.js';
import '~/vendor/luxon';

import AuditLog from '~/components/Admin/AuditLog.vue';

export default initBase(AuditLog);
