import initBase from '~/base.js';

import '~/vendor/luxon';

import Schedule from '~/components/Public/Schedule.vue';

export default initBase(Schedule);
