import initBase from '~/base.js';

import '~/vendor/fancybox';

import Requests from '~/components/Public/Requests.vue';

export default initBase(Requests);
