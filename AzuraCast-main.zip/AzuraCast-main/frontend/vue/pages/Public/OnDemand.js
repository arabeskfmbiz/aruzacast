import initBase from '~/base.js';

import '~/vendor/fancybox';

import OnDemand from '~/components/Public/OnDemand.vue';

export default initBase(OnDemand);
