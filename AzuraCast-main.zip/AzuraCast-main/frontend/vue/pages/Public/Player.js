import initBase from '~/base.js';

import Player from '~/components/Public/Player.vue';

export default initBase(Player);
