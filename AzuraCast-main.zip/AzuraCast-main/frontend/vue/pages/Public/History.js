import initBase
  from '~/base.js';

import '~/vendor/luxon';

import History
  from '~/components/Public/History.vue';

export default initBase(History);
