import initBase from '~/base.js';

import Account from '~/components/Account';

export default initBase(Account);
